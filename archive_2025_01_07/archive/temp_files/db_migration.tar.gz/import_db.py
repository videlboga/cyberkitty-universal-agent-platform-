#!/usr/bin/env python3
"""
Импорт данных в MongoDB на сервере
"""

import pymongo
import json
import os
from bson import ObjectId
from datetime import datetime

def parse_date(date_str):
    """Конвертирует ISO строку обратно в datetime"""
    try:
        return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
    except:
        return date_str

def parse_object_id(obj_id_str):
    """Конвертирует строку обратно в ObjectId"""
    try:
        return ObjectId(obj_id_str)
    except:
        return obj_id_str

def process_document(doc):
    """Обрабатывает документ, конвертируя строки обратно в правильные типы"""
    if isinstance(doc, dict):
        result = {}
        for key, value in doc.items():
            if key == '_id' and isinstance(value, str):
                result[key] = parse_object_id(value)
            elif isinstance(value, str) and ('T' in value and ('Z' in value or '+' in value)):
                # Возможная дата в ISO формате
                result[key] = parse_date(value)
            elif isinstance(value, (dict, list)):
                result[key] = process_document(value)
            else:
                result[key] = value
        return result
    elif isinstance(doc, list):
        return [process_document(item) for item in doc]
    else:
        return doc

# Подключение к MongoDB на сервере
client = pymongo.MongoClient('mongodb://admin:password123@127.0.0.1:27018/universal_agent_platform?authSource=admin')
db = client.universal_agent_platform

print("Подключение к MongoDB на сервере...")

# Папка с экспортированными данными
export_dir = 'db_export'

if not os.path.exists(export_dir):
    print(f"Папка {export_dir} не найдена!")
    exit(1)

# Импортируем каждую коллекцию
collections = ['scenarios', 'channel_mappings', 'users', 'user_states', 'settings']

for collection_name in collections:
    file_path = f'{export_dir}/{collection_name}.json'
    
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            documents = json.load(f)
        
        if documents:
            # Обрабатываем документы для восстановления типов
            processed_docs = [process_document(doc) for doc in documents]
            
            collection = db[collection_name]
            # Очищаем коллекцию перед импортом
            collection.delete_many({})
            # Вставляем документы
            result = collection.insert_many(processed_docs)
            print(f'Imported {len(result.inserted_ids)} documents to {collection_name}')
        else:
            print(f'No documents to import for {collection_name}')
    else:
        print(f'File {file_path} not found, skipping {collection_name}')

print('Import completed!') 