#!/usr/bin/env python3
"""
Скрипт для загрузки YAML сценариев в MongoDB
"""

import os
import yaml
import logging
from pymongo import MongoClient
from typing import Dict, Any

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def load_yaml_file(file_path: str) -> Dict[str, Any]:
    """Загружает YAML файл и возвращает содержимое"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = yaml.safe_load(file)
            return content
    except Exception as e:
        logger.error(f"Ошибка загрузки файла {file_path}: {e}")
        return None

def upload_scenario(collection, scenario_data: Dict[str, Any]) -> bool:
    """Загружает сценарий в MongoDB"""
    try:
        scenario_id = scenario_data.get('scenario_id')
        if not scenario_id:
            logger.error("scenario_id не найден в данных сценария")
            return False
        
        # Обновляем или вставляем сценарий
        result = collection.replace_one(
            {"scenario_id": scenario_id},
            scenario_data,
            upsert=True
        )
        
        if result.upserted_id:
            logger.info(f"✅ Сценарий {scenario_id} добавлен")
        else:
            logger.info(f"✅ Сценарий {scenario_id} обновлен")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка загрузки сценария: {e}")
        return False

def main():
    """Основная функция"""
    try:
        # Подключение к MongoDB
        client = MongoClient("mongodb://admin:password123@localhost:27018/universal_agent_platform?authSource=admin")
        db = client["universal_agent_platform"]
        collection = db["scenarios"]
        
        logger.info("Подключение к MongoDB установлено")
        
        # Путь к папке со сценариями
        scenarios_dir = "scenarios"
        
        if not os.path.exists(scenarios_dir):
            logger.error(f"Папка {scenarios_dir} не найдена")
            return
        
        # Получаем все YAML файлы
        yaml_files = [f for f in os.listdir(scenarios_dir) if f.endswith('.yaml') or f.endswith('.yml')]
        
        if not yaml_files:
            logger.warning("YAML файлы не найдены в папке scenarios")
            return
        
        logger.info(f"Найдено {len(yaml_files)} YAML файлов")
        
        success_count = 0
        error_count = 0
        
        # Загружаем каждый файл
        for yaml_file in yaml_files:
            file_path = os.path.join(scenarios_dir, yaml_file)
            logger.info(f"Обрабатываю файл: {yaml_file}")
            
            # Загружаем содержимое файла
            scenario_data = load_yaml_file(file_path)
            if scenario_data is None:
                error_count += 1
                continue
            
            # Загружаем в MongoDB
            if upload_scenario(collection, scenario_data):
                success_count += 1
            else:
                error_count += 1
        
        logger.info(f"\n=== РЕЗУЛЬТАТ ===")
        logger.info(f"✅ Успешно загружено: {success_count}")
        logger.info(f"❌ Ошибок: {error_count}")
        logger.info(f"📁 Всего файлов: {len(yaml_files)}")
        
        if error_count == 0:
            logger.info("🎉 Все сценарии успешно загружены!")
        
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
    finally:
        if 'client' in locals():
            client.close()
            logger.info("Соединение с MongoDB закрыто")

if __name__ == "__main__":
    main() 